#!/bin/sh

cp="."
for f in lib/*.jar; do
    cp="${cp}:${f}"
done

java -cp ${cp}							\
    -Djava.rmi.server.codebase="file://$PWD/lib/alfa-1.0-SNAPSHOT.jar file://$PWD/lib/alfa-pi-1.0-SNAPSHOT.jar"	\
    fr.unicaen.iota.application.rmi.RMIServer
